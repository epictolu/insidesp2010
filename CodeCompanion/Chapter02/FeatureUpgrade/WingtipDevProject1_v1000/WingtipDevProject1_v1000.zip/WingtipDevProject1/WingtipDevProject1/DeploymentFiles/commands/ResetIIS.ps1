﻿Write-Host "Executing Powershell script ResetIIS.ps1"

Write-Host "Restarting IIS Services..."
iisreset /noforce